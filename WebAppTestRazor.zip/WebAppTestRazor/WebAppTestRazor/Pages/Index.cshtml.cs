﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebAppTestRazor.Pages
{
    public class IndexModel : PageModel
    {
        public string? Nome { get; set; }
        public int Idade { get; set; }
        public void OnPost()
        {
            Nome = Request.Form["Nome"];
            Idade = Convert.ToInt32(Request.Form["Idade"]);
            ViewData["nome"] = $"Seu nome é {Nome}";
            ViewData["idade"] = $"Sua idade é {Idade}";
        }
    }
}